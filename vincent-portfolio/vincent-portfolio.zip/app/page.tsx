'use client'

import Sidebar from '@/components/sidebar/Sidebar'
import TabBar from '@/components/tabs/TabBar'
import CodeEditor from '@/components/editor/CodeEditor'
import Terminal from '@/components/terminal/Terminal'
import { RunBuildProvider } from '@/components/editor/RunBuildContext'

export default function Home() {
  return (
    <RunBuildProvider>
    <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh', overflow: 'hidden', background: '#1e1e1e', color: '#d4d4d4', fontFamily: "'Segoe UI', system-ui, sans-serif", fontSize: '13px' }}>

      {/* Title bar */}
      <div style={{ height: '30px', background: '#323233', display: 'flex', alignItems: 'center', padding: '0 12px', gap: '6px', flexShrink: 0, userSelect: 'none' }}>
        <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#ff5f57' }} />
        <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#febc2e' }} />
        <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#28c840' }} />
        <div style={{ flex: 1, textAlign: 'center', fontSize: '11px', color: '#9d9d9d' }}>
          vincent-portfolio — Visual Studio Code
        </div>
      </div>

      {/* Menu bar */}
      <div style={{ height: '24px', background: '#323233', borderBottom: '1px solid #252526', display: 'flex', alignItems: 'center', padding: '0 8px', gap: '2px', flexShrink: 0 }}>
        {['File', 'Edit', 'View', 'Go', 'Run', 'Terminal', 'Help'].map((item) => (
          <div key={item} style={{ padding: '2px 8px', fontSize: '11px', color: '#bdbdbd', cursor: 'pointer', borderRadius: '3px' }}
            onMouseEnter={(e) => (e.currentTarget.style.background = '#3a3a3a')}
            onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
            {item}
          </div>
        ))}
      </div>

      {/* Tab bar */}
      <TabBar />

      {/* Body */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* Activity bar */}
        <div style={{ width: '48px', background: '#333333', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '6px 0', gap: '4px', flexShrink: 0 }}>
          {[
            { icon: 'ti-files', active: true, title: 'Explorer' },
            { icon: 'ti-search', active: false, title: 'Search' },
            { icon: 'ti-git-branch', active: false, title: 'Source Control' },
            { icon: 'ti-puzzle', active: false, title: 'Extensions' },
          ].map((item) => (
            <div key={item.icon} title={item.title} style={{ width: '36px', height: '36px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', borderRadius: '4px', color: item.active ? '#fff' : '#858585', position: 'relative' }}>
              {item.active && <div style={{ position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)', width: '2px', height: '24px', background: '#fff', borderRadius: '0 2px 2px 0' }} />}
              <i className={`ti ${item.icon}`} style={{ fontSize: '22px' }} aria-hidden="true" />
            </div>
          ))}
          <div style={{ marginTop: 'auto', width: '36px', height: '36px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#858585' }}>
            <i className="ti ti-user-circle" style={{ fontSize: '22px' }} aria-hidden="true" />
          </div>
        </div>

        {/* Sidebar + main */}
        <Sidebar />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <CodeEditor />
          <Terminal />
        </div>
      </div>

      {/* Status bar */}
      <div style={{ height: '22px', background: '#007acc', display: 'flex', alignItems: 'center', padding: '0 10px', gap: '14px', flexShrink: 0 }}>
        <div style={{ fontSize: '11px', color: '#fff', display: 'flex', alignItems: 'center', gap: '4px', opacity: 0.9 }}>
          <i className="ti ti-git-branch" style={{ fontSize: '13px' }} aria-hidden="true" /> main
        </div>
        <div style={{ fontSize: '11px', color: '#fff', display: 'flex', alignItems: 'center', gap: '4px', opacity: 0.9 }}>
          <i className="ti ti-check" style={{ fontSize: '13px' }} aria-hidden="true" /> 0 errors
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: '14px' }}>
          {['TypeScript', 'UTF-8', 'Ln 1, Col 1', 'vincent.dev'].map((s) => (
            <div key={s} style={{ fontSize: '11px', color: '#fff', opacity: 0.9 }}>{s}</div>
          ))}
        </div>
      </div>
    </div>
    </RunBuildProvider>
  )
}